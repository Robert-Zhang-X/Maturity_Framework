# 题库格式规范（bank schema）

题库是单个 JSON 文件。只要符合本规范，引擎就能跑，与题目内容无关。

## 顶层结构

```jsonc
{
  "bank_id": "nist-csf-v1",            // 必填，唯一标识；--bank 用它查找
  "title": "NIST CSF 网络安全能力成熟度评估",
  "description": "一句话说明这份问卷是什么",
  "version": "1.0",
  "language": "zh-CN",

  "scale": {                            // 分值与等级
    "min": 0,
    "max": 5,
    "type": "maturity",
    "levels": [                         // 按顺序匹配，命中第一条即返回
      { "max_exclusive": 1.5, "label": "初始级", "desc": "控制措施大多是临时性的" },
      { "max_exclusive": 2.5, "label": "受管级", "desc": "" },
      { "max_exclusive": 3.5, "label": "已定义级", "desc": "" },
      { "max_exclusive": 4.5, "label": "量化管理级", "desc": "" },
      { "max_exclusive": null, "label": "优化级", "desc": "" }   // null = 兜底档
    ]
  },

  "aggregation": {                      // 可选，缺省值如下
    "group":   "mean_of_questions",     // 组内题目平均（也可 "sum"）
    "domain":  "mean_of_groups",        // 域内各组等权平均（也可 "mean_of_questions" 按题加权）
    "overall": "mean_of_domains",       // 各域等权平均（也可 "mean_of_groups" / "mean_of_questions"）
    "round": 2,                         // 保留小数位（复刻 JS Math.round 语义）
    "skip_unanswered": true             // 未答题跳过不计入平均
  },

  "domains": [ { "id": "Identity", "label": "识别 (Identify)", "icon": "🔍" } ],
  "groups":  [ { "id": "Identity::Asset Management", "domain": "Identity", "label": "资产管理", "icon": "🖥️" } ],
  "questions": [ /* 见下 */ ]
}
```

## 题目结构

```jsonc
{
  "id": "Identify-5",                   // 必填，全局唯一；答案文件用它做键
  "domain": "Identity",                 // 必填，须在 domains 中存在
  "group": "Identity::Asset Management",// 必填，须在 groups 中存在
  "text": "是否对所有 IT 资产建立集中台账并指定责任人？",

  "options": [                          // 必填，至少 1 项
    { "label": "A", "text": "没有台账", "score": 1 },
    { "label": "B", "text": "Excel 台账，覆盖不全", "score": 2 },
    { "label": "C", "text": "集中台账，覆盖完整", "score": 3 }
  ],

  "na": { "label": "N/A", "score": 1 }, // 可选；有则 N/A 为合法答案并按此计分

  "followups": ["用什么工具做资产盘点？"],  // 可选，开放式追问，不计分
  "preset_answer": "C"                  // 可选，预置答案（仅作参考，不参与计分）
}
```

**关键约束**

- `score` 是**逐选项给定**的，允许任意映射：可以 A=1/B=4/C=5 跳级，可以只有 2 个选项，也可以全是负分。引擎从不假设 A=1。
- `label` 匹配时忽略大小写（用户输入 `a` 等同 `A`）。
- `na.score` 多数为 1（不适用视为最低成熟度），也可以是 0（完全不计入惩罚）——按业务语义定。
- 未作答 = 答案缺失或空字符串，跳过不计分。

## 校验

```bash
python scripts/qscore.py validate my_bank.json
```

会检查：必填字段、id 唯一性、选项完整性、group/domain 引用有效性，并提示空组、无组归属的题。

## 从其他格式转换

从 Excel / 网页 / 现有 JSON 造题库时：

1. **先摸清计分表**：找到"选项 → 分值"的映射，确认是否存在跳级、N/A 的特殊分值。
2. **确定分组层级**：域（顶层）→ 组（中层）→ 题（底层）。若源数据只有一层分组，`groups` 直接复制成一层即可。
3. **确认聚合方式**：源系统若是"先组内平均、再各组等权平均"，就保持默认 `mean_of_groups`；若源系统按题目数加权，改用 `mean_of_questions`。这直接影响总分，务必和源系统对齐。
4. **对拍验证**：用一组已知答案，分别在源系统和本引擎上算一遍，逐层比对。这是唯一能保证分数一致的方法。

模板见 `assets/bank_template.json`。
