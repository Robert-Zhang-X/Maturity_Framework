@echo off
chcp 65001 >nul 2>nul
setlocal enabledelayedexpansion

set "SRC=%~dp0"
set "DST=%USERPROFILE%\.workbuddy\skills\questionnaire-scoring"

echo.
echo  Installing: Questionnaire Scoring Skill
echo  From: %SRC%
echo  To:   %DST%
echo.

if not exist "%USERPROFILE%\.workbuddy\skills" (
    mkdir "%USERPROFILE%\.workbuddy\skills"
)

if exist "%DST%" (
    echo  Existing installation found, overwriting...
)

xcopy /E /Y /I /Q "%SRC%" "%DST%" >nul

if errorlevel 1 (
    echo.
    echo  [FAILED] Could not copy files.
    echo  Try running as administrator, or copy the folder manually.
) else (
    echo.
    echo  [OK] Installed successfully.
    echo  Please restart WorkBuddy, then ask:
    echo      "list available question banks"
)

echo.
pause
