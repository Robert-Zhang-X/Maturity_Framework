---
name: questionnaire-scoring
slug: questionnaire-scoring
displayName: 问卷评分引擎
summary: 把"选择题+选项分值"的问卷变成一条命令出报告：逐题计分、按组/域分层汇总、算总分定等级，输出带雷达图的 HTML 报告。内置 NIST CSF 安全成熟度题库 158 题，与网页版逐分对齐；也支持塞入任意自定义问卷。
license: MIT
version: 1.0.0
description: 问卷测评打分引擎。把"提问→选答案→按答案给分→分层汇总出总分和等级"这件事做成可复用工具：加载题库、逐题收集答案、按组/域聚合、生成 Markdown、HTML 或 JSON 报告。内置 NIST CSF 网络安全成熟度评估题库（158 题 / 24 能力域 / 4 域，与网页版逐分对齐）。当用户要做问卷打分、成熟度评估、能力评估、测评系统、按选项计分并汇总总分，或提到 NIST CSF 评估、安全能力成熟度自评时使用。
display_name: "问卷评分引擎"
display_name_en: "Questionnaire Scoring Engine"
description_zh: "把选择题问卷变成一条命令出报告：逐题按选项计分，按能力域/领域分层汇总，算出总分与成熟度等级，输出含雷达图的 HTML 报告。评分由确定性脚本完成，不让模型心算。内置 NIST CSF 网络安全成熟度题库（158 题 / 24 能力域 / 4 域，与原版网页逐分对齐），也支持导入任意自定义问卷题库。纯 Python 标准库，零第三方依赖。"
description_en: "Turn any multiple-choice questionnaire into a scored report with one command: per-question scoring, hierarchical aggregation by capability/domain, overall score and maturity level, rendered as a self-contained HTML report with radar chart. Scoring is done by deterministic scripts, never by the model. Ships with the NIST CSF cybersecurity maturity bank (158 questions / 24 capabilities / 4 domains, score-for-score aligned with the original web tool), and accepts any custom question bank. Pure Python stdlib, zero third-party dependencies."
category: "data-analysis"
author: "Robert"
agent_created: true
---

# 问卷评分引擎

把一份"选择题 + 选项分值 + 分层汇总"的问卷，变成一条命令出报告的能力。评分是**确定性脚本**完成的，不要让 LLM 心算分数——158 题的加权平均，模型必错。

## 决策：用哪个题库

| 场景 | 做法 |
|---|---|
| NIST CSF 网络安全成熟度评估 | 直接用内置 `nist-csf-v1`，零配置 |
| 有别的问卷要打分 | 按 `references/bank-schema.md` 造题库 JSON → `validate` → 用 `--bank <路径>` 跑 |
| 用户给的问卷是 Excel/网页 | 先按 schema 转成题库 JSON（可让我做），再走上面的流程 |

## 标准工作流

```bash
PY="python"   # 用托管 venv 或系统 python 均可，无第三方依赖
QS="<SKILL_DIR>/scripts/qscore.py"
```

**1. 确认题库**

```bash
$PY $QS banks                          # 列出内置题库
$PY $QS info --bank nist-csf-v1 -v     # 看域/组/题数结构
```

**2. 生成答案文件**

```bash
$PY $QS template --bank nist-csf-v1 --out answers.json
```

文件长这样：`{"bank": "...", "respondent": "XX公司", "answers": {"Identify-5": "", ...}}`

**3. 收集答案**（三选一，别混用）

- **A. 我逐题问用户**（对话式评估推荐）：
  ```bash
  $PY $QS show --bank nist-csf-v1 --group "Identity::Asset Management"
  ```
  拿到题目和选项后向用户提问，把答案写进 `answers.json`。一次问一组（4-15 题）效率最高，不要一次甩 158 题。
  用 `next answers.json --n 10` 查还剩哪些没答。

- **B. 用户自己在终端填**：
  ```bash
  $PY $QS ask --bank nist-csf-v1 --answers answers.json --score
  ```

- **C. 已有答案数据**：按上面格式整理成 JSON 即可。

**4. 出报告**

```bash
$PY $QS score answers.json --format html --out report.html   # 给人看，推荐
$PY $QS score answers.json --format md   --out report.md     # 纯文本，便于二次编辑
$PY $QS score answers.json --format json --out result.json   # 结构化，供程序消费
```

**html**：单文件、零依赖、离线可开。含 Ocean Gradient 配色的头部、4 域 SVG 雷达图、带条形图的能力域明细表、Top5 改进项（含下一级目标）、低分题清单、N/A 复核清单、未作答题。适合直接交付给被评估方。

**md / json**：内容与 html 一致，分别是纯文本表格和结构化数据。

## 批量填充答案（测试 / 演示 / 看量表边界）

用户常会要求"先随便填一个跑通看看"。别临时写脚本，用 `fill`：

```bash
$PY $QS fill answers.json --strategy all:B                 # 全选 B
$PY $QS fill answers.json --strategy random --seed 42      # 随机（12% 留空）
$PY $QS fill answers.json --strategy first                 # 全选最低档 → 看下界分
$PY $QS fill answers.json --strategy last                  # 全选最高档 → 看上界分
$PY $QS fill answers.json --strategy random --score --format html --report-out r.html
```

`--score` 可接着直接出报告，一条命令完成"填答案 + 出报告"。

**注意**：题库里存在只有 1 个选项的题目（NIST 题库的 Protect-64 只有 A），`all:B` 遇到这类题会自动改用第一个可用选项并在终端列出，不会静默算错。

`first` / `last` 不只是测试用——它们给出量表的实际上下界。NIST 题库实测：全选最低 ≈ 1.0x，全选最高 ≈ **4.04**（不是 5.00，因为 16 道跳级题的最高档只有 3~5 分不等）。

## 对话式收集答案时接受的格式

用户不会按你设想的格式回，以下都要能接住：

- 带题号：`1=C 2=B 3=A`（推荐，不易错位）
- 纯序列：`C B A` / `C,B,A` / 一行一个
- 自然语言：「第1题我们有 Excel 台账但覆盖不全」→ 由你映射成字母，拿不准要回问确认
- 部分作答：`1=C 3=A`（其余留空，不计分）
- 跳过 / 不适用：`4=跳过` / `2=N/A`
- 整组打包：「这6题全 C」

一次问**一组**（4-15 题），不要一次甩 158 题。可随时中断出报告。

## 题库自带的数据缺陷（NIST 内置题库）

原始 Excel/网页有 5 处缺陷，已审计写入题库的 `data_quality` 字段。**引擎按原样计分以保持与网页版一致，不擅自修正**——擅自改会让分数和源系统对不上。

| 题目 | 问题 |
|---|---|
| Detect-13 / Detect-14 | 是非题（有无专职监控团队 / 是否订阅 SOC），但 A、B 两个选项**都是 0 分**，作答不影响得分 |
| Protect-64 | 只有 1 个计分选项（A=4） |

`info`、`validate`、`score` 都会提示这些缺陷；HTML 报告末尾有专门一节。实际评估时**要就这些题向受访方口头确认**，不能直接采信得分。

## 计分规则（通用，改题库可调）

1. **单题分** = 所选选项的 `score`，由题库自带。**不可假设 A=1/B=2**——内置 NIST 题库有 16 道题是跳级映射（如 A=1、B=4、C=5）。
2. **N/A 是有效作答**，按题库 `na.score` 计入（NIST 题库多数为 1 分，4 道题为 0 分），会拉低得分。
3. **未作答（空）跳过**，不参与平均。因此部分作答也能出分，但要看报告里的完成度。
4. **组（能力域）分** = 组内已答题的算术平均。
5. **域分** = 该域下所有组分的**等权平均**（组大题多也不额外加权）。
6. **总分** = 各域分的**等权平均**（不是全部 158 题的直接平均）。
7. 四舍五入复刻 JS `Math.round(x*100)/100`，与网页版结果逐分一致（已对拍验证 29 项指标）。

等级切分（可在题库 `scale.levels` 改）：<1.5 初始级 → <2.5 受管级 → <3.5 已定义级 → <4.5 量化管理级 → ≥4.5 优化级。

## CLI 速查

| 命令 | 用途 |
|---|---|
| `banks` | 列出内置题库 |
| `info --bank ID [-v]` | 题库结构概览 |
| `show --bank ID [--domain D] [--group G] [--compact]` | 打印题目原文+选项+分值，供提问 |
| `next <answers.json> [--n K]` | 列出未作答题 |
| `template [--domain D] [--out F]` | 生成空白答案文件 |
| `fill <answers.json> [--strategy all:B\|random\|first\|last] [--score]` | 批量填答案，用于测试或看量表边界 |
| `score <answers.json> [--format md\|html\|json] [--out F] [--top N]` | 评分出报告（html 最美观） |
| `ask [--group G] [--answers F] [--score]` | 终端交互式作答 |
| `validate <bank.json>` | 校验自定义题库 |
| `python scripts/audit_bank.py <bank.json> [--dry-run]` | 审计题库数据缺陷（无区分度/缺描述等），写入 `data_quality` 字段 |
| `python scripts/pack_skill.py [--edition client\|marketplace] [--verify]` | 打包分享：`client`=给终端客户（剔除 tests 和打包脚本，带一键安装）；`marketplace`=提交市场上架（保留 tests，带上架信息表）。默认输出到桌面 |

`--bank` 接受内置 bank_id（如 `nist-csf-v1`）或 JSON 文件路径。

## Python API（想在脚本里直接调用）

```python
import sys; sys.path.insert(0, r"<SKILL_DIR>\scripts")
from engine import load_bank
bank = load_bank("nist-csf-v1")
result = bank.evaluate({"Identify-5": "C", "Protect-5": "B"}, respondent="XX公司")
result["overall"]["score"]      # 2.19
result["overall"]["level"]      # '受管级 (Managed)'
result["groups"]                # 24 个能力域得分
result["weakest_groups"]        # 最弱 N 个
```

## 造自己的题库

见 `references/bank-schema.md`。最小骨架可直接复制 `assets/bank_template.json`（3 题示例），改完跑：

```bash
$PY $QS validate my_bank.json
```

## 回归测试

改过 `scripts/engine.py` 之后必跑：

```bash
$PY "<SKILL_DIR>/tests/test_engine.py"
```

用 158 题固定答案比对 `tests/nist_expected_scores.json` 里的期望值。这些期望值不是手算的，是**用 Node 跑网页原版 JS 评分函数实际得出的**，覆盖总分、4 个域、24 个能力域共 29 项，另含自定义题库和边界情况两组用例。全绿才算没改坏。

## 分享给别人

```bash
python scripts/pack_skill.py --edition client --verify        # 给客户/同事
python scripts/pack_skill.py --edition marketplace --verify   # 提交市场上架
```

打包会自动把文档里的本机路径换成 `<SKILL_DIR>` 占位符，换机器不失效。

**目录必须保持两级**（`scripts/lib/`、`tests/fixtures/` 这类三级目录会违反市场上传约束）——
这是为什么 `engine.py` 直接放在 `scripts/` 下而不是 `scripts/lib/`。

## 注意事项

- **不要心算分数**，一律走 `score` 命令或 `evaluate()`。
- 答案必须落在题目的选项内，否则按未作答处理，并会在报告"数据告警"里列出。
- 报告分数基于已答部分；未答过多时要在结论里说明置信度。
- 追问项（`followups`）是开放式补充问题，不计分，但评估访谈时值得一起问，用于定性佐证。
- 内置题库来自 NIST CSF 评估工具网页版，题目原文为英文，域/能力域名已带中文对照。
