"""通用问卷评分引擎 / Generic questionnaire scoring engine.

题库格式见 references/bank-schema.md。
核心职责：
  1. 加载题库（内置 bank_id 或外部 json 路径）
  2. 校验题库结构与答案合法性
  3. 分层聚合：题目分 -> 组 -> 域 -> 总分
  4. 映射到等级（scale.levels）

设计要点（源自 NIST CSF 网页版评估工具的逆向实现）：
  - 每题的选项分值由题库自带，允许"跳级"映射（如 A=1, B=4, C=5），不可假设 A=1
  - N/A 是有效作答，按题库中 na.score 计入（多数为 1，个别题为 0）
  - 未作答（空）跳过，不参与平均
  - 舍入复刻 JS Math.round(x*100)/100 语义：floor(x*100+0.5)/100
"""

from __future__ import annotations

import json
import math
import os
import re

# scripts/engine.py -> scripts -> skill root
_SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_DIR = os.path.join(_SKILL_ROOT, "assets")


class BankError(Exception):
    """题库结构或内容错误。"""


def js_round(value: float, digits: int = 2) -> float:
    """复刻 JS Math.round(v * 10**d) / 10**d，保证与网页版分数一致。"""
    factor = 10 ** digits
    return math.floor(value * factor + 0.5) / factor


def _mean(values, digits: int = 2):
    if not values:
        return None
    return js_round(sum(values) / len(values), digits)


class Bank:
    """已加载的问卷题库。"""

    def __init__(self, data: dict, path: str = None):
        self.path = path
        self.raw = data
        self._validate()
        self.bank_id = data.get("bank_id") or "unnamed"
        self.title = data.get("title") or self.bank_id
        self.description = data.get("description") or ""
        self.scale = data.get("scale") or {}
        self.levels = self.scale.get("levels") or []
        self.agg = {
            "group": "mean_of_questions",
            "domain": "mean_of_groups",
            "overall": "mean_of_domains",
            "round": 2,
            "skip_unanswered": True,
        }
        self.agg.update(data.get("aggregation") or {})

        self.domains = data.get("domains") or []
        self.groups = data.get("groups") or []
        self.questions = data.get("questions") or []

        self._q_by_id = {q["id"]: q for q in self.questions}
        self._domain_label = {d["id"]: d.get("label", d["id"]) for d in self.domains}
        self._group_label = {g["id"]: g.get("label", g["id"]) for g in self.groups}
        # 保持题库声明顺序，输出时更可读
        self._domain_order = [d["id"] for d in self.domains]
        self._group_order = [g["id"] for g in self.groups]

    # ---------- 校验 ----------
    def _validate(self):
        data = self.raw
        required = ["bank_id", "questions"]
        missing = [k for k in required if k not in data]
        if missing:
            raise BankError(f"题库缺少必需字段: {missing}")

        qids = [q.get("id") for q in data["questions"]]
        if not qids:
            raise BankError("题库没有任何题目")
        dup = {q for q in qids if qids.count(q) > 1}
        if dup:
            raise BankError(f"题目 id 重复: {sorted(dup)[:5]}")

        for q in data["questions"]:
            for f in ("id", "text", "options"):
                if f not in q:
                    raise BankError(f"题目 {q.get('id')} 缺少字段 {f}")
            if not q["options"]:
                raise BankError(f"题目 {q['id']} 没有选项")
            for o in q["options"]:
                if "label" not in o or "score" not in o:
                    raise BankError(f"题目 {q['id']} 的选项缺少 label/score: {o}")

        gids = {g.get("id") for g in data.get("groups", [])}
        dids = {d.get("id") for d in data.get("domains", [])}
        for q in data["questions"]:
            if gids and q.get("group") and q["group"] not in gids:
                raise BankError(f"题目 {q['id']} 引用了不存在的组 {q['group']}")
            if dids and q.get("domain") and q["domain"] not in dids:
                raise BankError(f"题目 {q['id']} 引用了不存在的域 {q['domain']}")

    # ---------- 查询 ----------
    @property
    def size(self):
        return {
            "questions": len(self.questions),
            "groups": len(self.groups),
            "domains": len(self.domains),
        }

    def option_labels(self, q):
        return [o["label"] for o in q["options"]] + ([q["na"]["label"]] if q.get("na") else [])

    def get_question(self, qid):
        return self._q_by_id.get(qid)

    def questions_of_group(self, gid):
        return [q for q in self.questions if q.get("group") == gid]

    def groups_of_domain(self, did):
        return [g for g in self.groups if g.get("domain") == did]

    def questions_of_domain(self, did):
        return [q for q in self.questions if q.get("domain") == did]

    # ---------- 计分 ----------
    def score_of(self, qid, answer):
        """单题得分。未答/非法答案返回 None。"""
        q = self._q_by_id.get(qid)
        if q is None:
            return None
        if answer is None:
            return None
        ans = str(answer).strip()
        if ans == "" or ans.lower() in ("null", "none"):
            return None
        ans_up = ans.upper()
        if q.get("na") and ans_up == str(q["na"]["label"]).upper():
            return float(q["na"]["score"])
        for o in q["options"]:
            if str(o["label"]).upper() == ans_up:
                return float(o["score"])
        return None

    def level_of(self, score):
        """分数 -> 等级标签。"""
        if score is None:
            return "未评估"
        for lv in self.levels:
            mx = lv.get("max_exclusive")
            if mx is None or score < mx:
                return lv.get("label", "")
        return self.levels[-1].get("label", "") if self.levels else ""

    def evaluate(self, answers: dict, respondent: str = None, top_n: int = 5):
        """执行完整评分。

        answers: {question_id: option_label}；未答可省略或置空。
        返回结构化结果 dict（可直接 JSON 序列化）。
        """
        digits = int(self.agg.get("round", 2))
        warnings = []

        q_scores = {}
        for q in self.questions:
            qid = q["id"]
            raw = answers.get(qid)
            sc = self.score_of(qid, raw)
            if raw not in (None, "") and sc is None:
                warnings.append(
                    f"题目 {qid} 的答案 '{raw}' 不在选项中，已按未作答处理"
                )
            q_scores[qid] = sc

        # --- 组 ---
        group_rows = []
        g_score = {}
        for gid in self._group_order:
            qs = self.questions_of_group(gid)
            vals = [q_scores[q["id"]] for q in qs if q_scores[q["id"]] is not None]
            mode = self.agg.get("group", "mean_of_questions")
            if mode == "sum":
                s = js_round(sum(vals), digits) if vals else None
            else:
                s = _mean(vals, digits)
            g_score[gid] = s
            group_rows.append({
                "id": gid,
                "label": self._group_label.get(gid, gid),
                "domain": next((g.get("domain") for g in self.groups if g["id"] == gid), None),
                "score": s,
                "level": self.level_of(s),
                "answered": len(vals),
                "total": len(qs),
            })

        # --- 域 ---
        domain_rows = []
        d_score = {}
        for did in self._domain_order:
            gs = [g["id"] for g in self.groups_of_domain(did)]
            gvals = [g_score[g] for g in gs if g_score[g] is not None]
            mode = self.agg.get("domain", "mean_of_groups")
            if mode == "mean_of_questions":
                vals = [q_scores[q["id"]] for q in self.questions_of_domain(did)
                        if q_scores[q["id"]] is not None]
                s = _mean(vals, digits)
            else:
                s = _mean(gvals, digits)
            d_score[did] = s
            answered = sum(1 for q in self.questions_of_domain(did)
                           if q_scores[q["id"]] is not None)
            domain_rows.append({
                "id": did,
                "label": self._domain_label.get(did, did),
                "score": s,
                "level": self.level_of(s),
                "group_count": len(gs),
                "groups_scored": len(gvals),
                "answered": answered,
                "total": len(self.questions_of_domain(did)),
            })

        # --- 总分 ---
        mode = self.agg.get("overall", "mean_of_domains")
        if mode == "mean_of_questions":
            vals = [v for v in q_scores.values() if v is not None]
        elif mode == "mean_of_groups":
            vals = [v for v in g_score.values() if v is not None]
        else:
            vals = [v for v in d_score.values() if v is not None]
        overall = _mean(vals, digits)

        answered_total = sum(1 for v in q_scores.values() if v is not None)
        total = len(self.questions)

        scored_groups = [g for g in group_rows if g["score"] is not None]
        weakest = sorted(scored_groups, key=lambda x: x["score"])[:top_n]
        strongest = sorted(scored_groups, key=lambda x: -x["score"])[:top_n]

        # 低分题：得分 <= 2 且已作答的题，按分数升序
        # 排除选了 N/A 的题 —— "不适用"不代表能力差，单独统计
        low_questions = []
        na_answers = []
        for q in self.questions:
            sc = q_scores[q["id"]]
            if sc is None:
                continue
            raw = str(answers.get(q["id"]) or "").strip().upper()
            is_na = raw == "N/A"
            row = {
                "id": q["id"],
                "group": q.get("group"),
                "group_label": self._group_label.get(q.get("group"), ""),
                "domain": q.get("domain"),
                "answer": answers.get(q["id"]),
                "score": sc,
                "text": q["text"],
            }
            if is_na:
                na_answers.append(row)
            elif sc <= 2:
                low_questions.append(row)
        low_questions.sort(key=lambda x: x["score"])
        na_answers.sort(key=lambda x: (x["group_label"], x["id"]))

        unanswered = [q["id"] for q in self.questions if q_scores[q["id"]] is None]

        return {
            "bank_id": self.bank_id,
            "bank_title": self.title,
            "respondent": respondent,
            "overall": {
                "score": overall,
                "level": self.level_of(overall),
                "scale_min": self.scale.get("min"),
                "scale_max": self.scale.get("max"),
            },
            "scale_levels": self.levels,
            "data_quality": self.raw.get("data_quality"),
            "progress": {
                "answered": answered_total,
                "total": total,
                "completeness": js_round(answered_total / total, 4) if total else 0,
            },
            "domains": domain_rows,
            "groups": group_rows,
            "answers_detail": [
                {
                    "id": q["id"],
                    "group": q.get("group"),
                    "domain": q.get("domain"),
                    "answer": answers.get(q["id"]) or None,
                    "score": q_scores[q["id"]],
                    "text": q["text"],
                }
                for q in self.questions
            ],
            "weakest_groups": weakest,
            "strongest_groups": strongest,
            "low_questions": low_questions,
            "na_answers": na_answers,
            "unanswered": unanswered,
            "warnings": warnings,
        }


# ---------- 加载 ----------

def resolve_bank_path(bank: str) -> str:
    """bank 可以是内置 bank_id、绝对路径或相对路径。"""
    if not bank:
        raise BankError("未指定题库")
    if os.path.isfile(bank):
        return bank
    # 1) 直接按文件名
    cand = os.path.join(ASSETS_DIR, bank if bank.endswith(".json") else bank + ".json")
    if os.path.isfile(cand):
        return cand
    # 2) 按 bank_id 反查（bank_id 可能含连字符而文件名用下划线）
    for b in list_banks():
        if b["bank_id"] == bank or b["file"] == bank:
            return os.path.join(ASSETS_DIR, b["file"])
    raise BankError(
        f"找不到题库 '{bank}'。已查找: {bank} 及内置目录 {ASSETS_DIR}\n"
        f"可用内置题库: {list_banks()}"
    )


def load_bank(bank: str = "nist-csf-v1") -> Bank:
    path = resolve_bank_path(bank)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return Bank(data, path=path)


def list_banks():
    """列出内置题库 (bank_id, title, 题数)。"""
    out = []
    if not os.path.isdir(ASSETS_DIR):
        return out
    for fn in sorted(os.listdir(ASSETS_DIR)):
        if not fn.endswith(".json") or fn.startswith("_") or fn.endswith("_template.json"):
            continue
        p = os.path.join(ASSETS_DIR, fn)
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            if "questions" not in d:
                continue
            out.append({
                "bank_id": d.get("bank_id", fn[:-5]),
                "file": fn,
                "title": d.get("title", ""),
                "questions": len(d["questions"]),
                "groups": len(d.get("groups", [])),
                "domains": len(d.get("domains", [])),
            })
        except Exception:
            continue
    return out


def load_answers(path: str):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "answers" in data and isinstance(data["answers"], dict):
        return data.get("bank"), data["answers"], data.get("respondent"), data.get("meta", {})
    # 也允许纯 {qid: label} 映射
    if isinstance(data, dict):
        return None, data, None, {}
    raise BankError(f"无法解析答案文件 {path}")
