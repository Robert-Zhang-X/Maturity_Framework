"""HTML 报告渲染器（零依赖，单文件离线可看，含 SVG 雷达图）。"""

import html
import math

# Ocean Gradient 配色
CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
 background:linear-gradient(160deg,#f0f7ff 0%,#e6f4f1 45%,#f7fbff 100%);
 color:#0f2740;line-height:1.6;padding:32px 16px}
.wrap{max-width:1080px;margin:0 auto}
.hero{background:linear-gradient(135deg,#0c4a6e 0%,#075985 45%,#0891b2 100%);
 border-radius:20px;padding:36px 40px;color:#fff;box-shadow:0 12px 32px rgba(8,60,90,.22);
 display:flex;justify-content:space-between;align-items:center;gap:32px;flex-wrap:wrap}
.hero h1{font-size:1.45rem;font-weight:600;letter-spacing:.3px;opacity:.95}
.hero .sub{font-size:.9rem;opacity:.8;margin-top:8px}
.hero-score{text-align:right;display:flex;align-items:baseline;gap:14px}
.big{font-size:4rem;font-weight:700;line-height:1;text-shadow:0 2px 12px rgba(0,0,0,.18)}
.big small{font-size:1.2rem;font-weight:400;opacity:.75}
.lvl{background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.35);
 border-radius:999px;padding:6px 16px;font-size:.95rem;font-weight:600;white-space:nowrap}
.chips{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
.chip{background:rgba(255,255,255,.16);border-radius:20px;padding:5px 14px;font-size:.8rem}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:22px}
@media(max-width:820px){.grid{grid-template-columns:1fr}}
.card{background:#fff;border-radius:16px;padding:24px 26px;
 box-shadow:0 4px 18px rgba(15,39,64,.07);border:1px solid rgba(15,39,64,.06)}
.card h2{font-size:1.05rem;font-weight:600;color:#0c4a6e;margin-bottom:16px;
 padding-bottom:10px;border-bottom:2px solid #e2eef6}
.dlist{display:flex;flex-direction:column;gap:14px}
.drow{display:flex;align-items:center;gap:12px}
.dname{width:112px;font-size:.9rem;flex-shrink:0;color:#284b66}
.bar{flex:1;height:11px;background:#eef4f8;border-radius:999px;overflow:hidden}
.fill{height:100%;border-radius:999px;transition:width .4s}
.dval{width:52px;text-align:right;font-weight:700;font-size:.95rem}
.dlvl{width:96px;font-size:.78rem;color:#5b7a94}
table{width:100%;border-collapse:collapse;font-size:.88rem}
th{text-align:left;padding:9px 10px;background:#f3f9fc;color:#0c4a6e;font-weight:600;
 font-size:.82rem;border-bottom:2px solid #dcebf3}
td{padding:9px 10px;border-bottom:1px solid #eef4f8;vertical-align:middle}
tr:hover td{background:#fafcfe}
td.num{text-align:right;font-variant-numeric:tabular-nums}
.tag{display:inline-block;padding:2px 9px;border-radius:999px;font-size:.75rem;font-weight:600}
.muted{color:#789}
.note{font-size:.82rem;color:#5b7a94;margin-top:12px;padding:12px 14px;
 background:#f6fafd;border-left:3px solid #0891b2;border-radius:0 8px 8px 0}
.qtext{color:#284b66;max-width:520px}
.qtext .t{display:block}
.sec{margin-top:22px}
ul.warn{list-style:none;font-size:.85rem}
ul.warn li{padding:6px 0;border-bottom:1px solid #f0f5f8;color:#8a5a12}
"""

LEVEL_COLORS = [
    (1.5, "#dc2626"), (2.5, "#ea580c"), (3.5, "#ca8a04"),
    (4.5, "#0891b2"), (99, "#059669"),
]


def color_of(score):
    if score is None:
        return "#94a3b8"
    for bound, c in LEVEL_COLORS:
        if score < bound:
            return c
    return "#059669"


def radar_svg(items, size=360, smax=5):
    """items: [(label, score)]，画 4~6 轴雷达图。"""
    n = len(items)
    if n < 3:
        return ""
    cx = cy = size / 2
    R = size / 2 - 62
    smax = smax or 5

    def pt(i, v):
        ang = -math.pi / 2 + 2 * math.pi * i / n
        r = R * (max(0.0, min(float(v), smax)) / smax)
        return cx + r * math.cos(ang), cy + r * math.sin(ang)

    parts = [f'<svg viewBox="0 0 {size} {size}" width="100%" style="max-width:{size}px">']
    # 同心网格
    for level in range(1, smax + 1):
        poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in (pt(i, level) for i in range(n)))
        parts.append(
            f'<polygon points="{poly}" fill="{"#f8fbfd" if level % 2 else "#f1f7fa"}" '
            f'stroke="#dbe8f0" stroke-width="1"/>'
        )
    # 轴线 + 刻度
    for i in range(n):
        x, y = pt(i, smax)
        parts.append(f'<line x1="{cx}" y1="{cy}" x2="{x:.1f}" y2="{y:.1f}" stroke="#dbe8f0"/>')
    for level in (1, 3, 5):
        x, y = pt(0, level)
        parts.append(
            f'<text x="{x + 5:.1f}" y="{y + 4:.1f}" font-size="10" fill="#9ab">'
            f'{level}</text>'
        )
    # 数据多边形
    dpts = [pt(i, v) for i, (_, v) in enumerate(items)]
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in dpts)
    parts.append(
        f'<polygon points="{poly}" fill="rgba(8,145,178,.22)" stroke="#0891b2" '
        f'stroke-width="2.5" stroke-linejoin="round"/>'
    )
    for (x, y), (_, v) in zip(dpts, items):
        parts.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4.5" fill="#fff" stroke="#0891b2" '
            f'stroke-width="2.5"/>'
        )
    # 轴标签
    for i, (label, v) in enumerate(items):
        ang = -math.pi / 2 + 2 * math.pi * i / n
        lx = cx + (R + 30) * math.cos(ang)
        ly = cy + (R + 30) * math.sin(ang)
        anchor = "middle" if abs(math.cos(ang)) < 0.3 else ("start" if math.cos(ang) > 0 else "end")
        esc = html.escape(str(label))
        val = "—" if v is None else f"{v:.2f}"
        parts.append(
            f'<text x="{lx:.1f}" y="{ly:.1f}" font-size="12.5" fill="#284b66" '
            f'text-anchor="{anchor}" font-weight="600">{esc}</text>'
        )
        parts.append(
            f'<text x="{lx:.1f}" y="{ly + 16:.1f}" font-size="12" fill="{color_of(v)}" '
            f'text-anchor="{anchor}" font-weight="700">{val}</text>'
        )
    parts.append("</svg>")
    return "".join(parts)


def _bar(score, smax=5):
    pct = 0 if score is None else max(0, min(score / smax, 1)) * 100
    c = color_of(score)
    return f'<div class="bar"><div class="fill" style="width:{pct:.0f}%;background:{c}"></div></div>'


def render(result, top_n=5):
    ov = result["overall"]
    prog = result["progress"]
    e = html.escape
    smax = ov.get("scale_max") or 5

    P = [f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">',
         f'<meta name="viewport" content="width=device-width,initial-scale=1">',
         f'<title>{e(result["bank_title"])} · 评估报告</title><style>{CSS}</style></head><body><div class="wrap">']

    # 头部
    who = e(result.get("respondent") or "未指定评估对象")
    P.append('<div class="hero"><div>')
    P.append(f'<h1>{e(result["bank_title"])}</h1>')
    P.append(f'<div class="sub">评估对象：{who}</div>')
    P.append('<div class="chips">')
    P.append(f'<span class="chip">完成度 {prog["answered"]}/{prog["total"]} '
             f'({prog["completeness"] * 100:.0f}%)</span>')
    P.append(f'<span class="chip">题库 {e(result["bank_id"])}</span>')
    P.append(f'<span class="chip">量表 {ov.get("scale_min", 0)}–{smax} 分</span>')
    P.append('</div></div>')
    P.append('<div class="hero-score">')
    big = "—" if ov["score"] is None else f'{ov["score"]:.2f}'
    P.append(f'<div class="big">{big}<small> / {smax}</small></div>')
    P.append(f'<div class="lvl">{e(ov["level"])}</div>')
    P.append('</div></div>')

    # 雷达图 + 域得分
    P.append('<div class="grid">')
    P.append('<div class="card"><h2>能力域雷达图</h2>')
    P.append(radar_svg([(d["label"], d["score"]) for d in result["domains"]], smax=smax))
    P.append('</div>')
    P.append('<div class="card"><h2>域得分</h2><div class="dlist">')
    for d in result["domains"]:
        c = color_of(d["score"])
        val = "—" if d["score"] is None else f'{d["score"]:.2f}'
        P.append('<div class="drow">')
        P.append(f'<div class="dname">{e(d["label"])}</div>')
        P.append(_bar(d["score"], smax))
        P.append(f'<div class="dval" style="color:{c}">{val}</div>')
        P.append(f'<div class="dlvl">{e(d["level"])}</div>')
        P.append('</div>')
    P.append('</div>')
    P.append(f'<div class="note">总分 = 四个域得分的等权平均，而非全部 '
             f'{prog["total"]} 道题的直接平均。</div>')
    P.append('</div></div>')

    # 能力域明细
    P.append('<div class="card sec"><h2>能力域得分明细</h2>')
    P.append('<table><thead><tr><th>域</th><th>能力域</th><th class="num">得分</th>'
             '<th>等级</th><th style="width:180px">分布</th><th class="num">已答</th></tr></thead><tbody>')
    for g in result["groups"]:
        dlabel = next((d["label"] for d in result["domains"] if d["id"] == g["domain"]), g["domain"] or "")
        c = color_of(g["score"])
        val = "—" if g["score"] is None else f'{g["score"]:.2f}'
        P.append("<tr>")
        P.append(f'<td class="muted">{e(dlabel)}</td>')
        P.append(f'<td><strong>{e(g["label"])}</strong></td>')
        P.append(f'<td class="num" style="color:{c};font-weight:700">{val}</td>')
        P.append(f'<td><span class="tag" style="background:{c}1a;color:{c}">{e(g["level"])}</span></td>')
        P.append(f'<td>{_bar(g["score"], smax)}</td>')
        P.append(f'<td class="num muted">{g["answered"]}/{g["total"]}</td>')
        P.append("</tr>")
    P.append('</tbody></table></div>')

    # 最需改进
    P.append(f'<div class="card sec"><h2>最需改进的 {top_n} 个能力域</h2>')
    P.append('<table><thead><tr><th class="num">#</th><th>能力域</th><th class="num">得分</th>'
             '<th>当前等级</th><th>下一级目标</th></tr></thead><tbody>')
    levels = result.get("scale_levels") or []
    for i, g in enumerate(result["weakest_groups"], 1):
        c = color_of(g["score"])
        nxt = _next_level(g["score"], levels)
        P.append("<tr>")
        P.append(f'<td class="num muted">{i}</td>')
        P.append(f'<td><strong>{e(g["label"])}</strong></td>')
        P.append(f'<td class="num" style="color:{c};font-weight:700">{g["score"]:.2f}</td>')
        P.append(f'<td><span class="tag" style="background:{c}1a;color:{c}">{e(g["level"])}</span></td>')
        P.append(f'<td class="muted">{e(nxt)}</td>')
        P.append("</tr>")
    P.append('</tbody></table></div>')

    # 低分题
    if result["low_questions"]:
        P.append(f'<div class="card sec"><h2>低分题目（≤2 分，共 {len(result["low_questions"])} 题）</h2>')
        P.append('<table><thead><tr><th>题目 ID</th><th>能力域</th><th class="num">答案</th>'
                 '<th class="num">得分</th><th>题目</th></tr></thead><tbody>')
        for q in result["low_questions"][:25]:
            t = e(q["text"].replace("\n", " "))
            t = t if len(t) <= 110 else t[:110] + "…"
            P.append("<tr>")
            P.append(f'<td class="muted">{e(q["id"])}</td>')
            P.append(f'<td>{e(q["group_label"])}</td>')
            P.append(f'<td class="num">{e(str(q.get("answer")))}</td>')
            P.append(f'<td class="num" style="color:#dc2626;font-weight:700">{q["score"]:.0f}</td>')
            P.append(f'<td class="qtext"><span class="t">{t}</span></td>')
            P.append("</tr>")
        P.append('</tbody></table>')
        if len(result["low_questions"]) > 25:
            P.append(f'<div class="note">另有 {len(result["low_questions"]) - 25} 题未在此列出。</div>')
        P.append('</div>')

    # N/A
    if result.get("na_answers"):
        P.append(f'<div class="card sec"><h2>回答「不适用」的题目（{len(result["na_answers"])} 题）</h2>')
        P.append('<div class="note">N/A 按题库设定计入得分（多数 1 分，少数 0 分），会影响分数。'
                 '但它代表「不适用」而非能力不足；N/A 过多可能意味着受访方在回避问题，建议访谈时复核。</div>')
        P.append('<table style="margin-top:14px"><thead><tr><th>题目 ID</th><th>能力域</th>'
                 '<th class="num">计入</th><th>题目</th></tr></thead><tbody>')
        for q in result["na_answers"][:25]:
            t = e(q["text"].replace("\n", " "))
            t = t if len(t) <= 110 else t[:110] + "…"
            P.append(f'<tr><td class="muted">{e(q["id"])}</td><td>{e(q["group_label"])}</td>'
                     f'<td class="num">{q["score"]:.0f}</td><td class="qtext">{t}</td></tr>')
        P.append('</tbody></table></div>')

    # 未作答
    if result["unanswered"]:
        P.append(f'<div class="card sec"><h2>未作答题目（{len(result["unanswered"])} 题）</h2>')
        P.append('<div class="note">未作答题不参与计分，当前分数基于已完成部分计算。</div>')
        P.append(f'<p class="muted" style="margin-top:12px;font-size:.82rem">'
                 f'{e(", ".join(result["unanswered"][:80]))}'
                 f'{" …" if len(result["unanswered"]) > 80 else ""}</p></div>')

    if result["warnings"]:
        P.append('<div class="card sec"><h2>数据告警</h2><ul class="warn">')
        for w in result["warnings"]:
            P.append(f'<li>{e(w)}</li>')
        P.append('</ul></div>')

    dq = result.get("data_quality") or {}
    if dq.get("issues"):
        P.append(f'<div class="card sec"><h2>题库数据质量提示（{dq["count"]} 处）</h2>')
        P.append('<div class="note">以下缺陷来自原始题库，引擎按原样计分以保持与源系统一致，'
                 '未擅自修正。这些题目的得分不可直接采信，评估时应向受访方口头确认。</div>')
        P.append('<table style="margin-top:14px"><thead><tr><th>题目 ID</th><th>类型</th>'
                 '<th>问题</th><th>题目</th></tr></thead><tbody>')
        for i in dq["issues"]:
            P.append(f'<tr><td class="muted">{e(i["id"])}</td><td>{e(i["type"])}</td>'
                     f'<td>{e(i["detail"])}</td>'
                     f'<td class="qtext">{e(i.get("text", ""))}</td></tr>')
        P.append('</tbody></table></div>')

    P.append('</div></body></html>')
    return "\n".join(P)


def _next_level(score, levels):
    if score is None or not levels:
        return "尚未评估"
    idx = 0
    for i, lv in enumerate(levels):
        mx = lv.get("max_exclusive")
        if mx is None or score < mx:
            idx = i
            break
    else:
        idx = len(levels) - 1
    if idx + 1 >= len(levels):
        return "已达最高级，维持并持续改进"
    nxt = levels[idx + 1]
    return f'{nxt.get("label", "")}：{nxt.get("desc", "")}'.strip("：")
