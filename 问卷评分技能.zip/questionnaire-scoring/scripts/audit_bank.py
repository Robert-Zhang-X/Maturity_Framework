#!/usr/bin/env python3
"""题库数据质量审计。

扫描题库中的逻辑缺陷，结果写入题库的 data_quality 字段（评分引擎不读该字段，
因此不影响分数——目的是让使用者知道哪些题的得分不可直接采信）。

    python audit_bank.py <bank.json>            # 审计并写回题库
    python audit_bank.py <bank.json> --dry-run  # 只报告不写入

检查项：
  single_option        只有 1 个计分选项
  no_discrimination    所有选项分值相同，作答不影响得分
  na_higher_than_max   N/A 分值高于最高选项（不适用反而拿高分）
  missing_option_text  选项缺描述文本
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine import resolve_bank_path  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def audit(data):
    issues = []
    for q in data.get("questions", []):
        qid = q.get("id", "?")
        opts = q.get("options") or []
        scores = [o.get("score") for o in opts]
        na = q.get("na")
        text = (q.get("text") or "")[:70]

        if len(scores) > 1 and len(set(scores)) == 1:
            issues.append({
                "id": qid, "type": "no_discrimination",
                "detail": f"所有选项均为 {scores[0]} 分，作答不影响得分", "text": text,
            })
        if na and scores and na.get("score") is not None and na["score"] > max(scores):
            issues.append({
                "id": qid, "type": "na_higher_than_max",
                "detail": f"N/A={na['score']} 高于最高选项 {max(scores)} 分", "text": text,
            })
        miss = [o.get("label") for o in opts if not (o.get("text") or "").strip()]
        if miss:
            issues.append({
                "id": qid, "type": "missing_option_text",
                "detail": f"选项 {', '.join(str(m) for m in miss)} 缺描述文本", "text": text,
            })
        if len(scores) == 1:
            issues.append({
                "id": qid, "type": "single_option",
                "detail": f"仅 1 个计分选项（{opts[0].get('label')}={scores[0]}）", "text": text,
            })
    return issues


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(1)
    dry = "--dry-run" in sys.argv
    path = resolve_bank_path(args[0])
    data = json.load(open(path, encoding="utf-8"))
    issues = audit(data)

    print(f"题库: {path}")
    print(f"发现 {len(issues)} 处数据缺陷")
    for i in issues:
        print(f"  [{i['type']}] {i['id']} — {i['detail']}")
        print(f"      {i['text']}")

    if not dry:
        data["data_quality"] = {
            "audited_by": "audit_bank.py",
            "note": "以下为原始题库自带的数据缺陷。引擎按原样计分以保持与源系统一致，"
                    "未擅自修正；实际评估时应就这些题目向受访方口头确认。",
            "count": len(issues),
            "issues": issues,
        }
        json.dump(data, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"\n已写入题库 data_quality 字段: {path}")
    else:
        print("\n(dry-run，未写入)")


if __name__ == "__main__":
    main()
