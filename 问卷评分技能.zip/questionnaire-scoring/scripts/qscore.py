#!/usr/bin/env python3
"""qscore.py —— 问卷评分命令行工具（供 Agent 调用）。

用法:
  qscore.py banks                                 列出可用题库
  qscore.py info   [--bank ID]                    题库概览（域/组/题数）
  qscore.py show   [--bank ID] [--domain D] [--group G] [--compact]   打印题目，供逐题提问
  qscore.py next   <answers.json> [--n K]         列出下一批未作答题目
  qscore.py template [--bank ID] [--domain D] [--out FILE]            生成空白答案文件
  qscore.py score  <answers.json> [--format md|json] [--out FILE] [--top N]
  qscore.py ask    [--bank ID] [--group G] [--answers FILE] [--out FILE]  终端交互式作答
  qscore.py validate <bank.json>                  校验自定义题库格式

答案文件格式:
  {"bank": "nist-csf-v1", "respondent": "某某公司", "answers": {"Identify-5": "C", ...}}
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine import (  # noqa: E402
    Bank, BankError, list_banks, load_answers, load_bank, resolve_bank_path,
)
import report_html  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

DEFAULT_BANK = "nist-csf-v1"


# ---------------- 输出辅助 ----------------

def _bar(score, smax=5, width=10):
    if score is None:
        return "─" * width
    filled = int(round(score / smax * width))
    return "█" * filled + "░" * (width - filled)


def _fmt_score(s):
    return "—" if s is None else f"{s:.2f}"


def print_question(q, idx=None, compact=False, with_answer=None):
    head = f"{'' if idx is None else f'[{idx}] '}{q['id']}"
    print(f"\n{head}")
    print(f"  {q['text']}")
    if not compact:
        for o in q["options"]:
            mark = " <=" if with_answer and str(with_answer).upper() == str(o["label"]).upper() else ""
            print(f"    {o['label']}. {o['text']}  ({o['score']}分){mark}")
        if q.get("na"):
            mark = " <=" if with_answer and str(with_answer).upper() == "N/A" else ""
            print(f"    {q['na']['label']}. 不适用  ({q['na']['score']}分){mark}")
    else:
        opts = "/".join(f"{o['label']}={o['score']}" for o in q["options"])
        print(f"    选项: {opts}" + (f" | N/A={q['na']['score']}" if q.get("na") else ""))
    if q.get("followups"):
        print("    追问:")
        for f in q["followups"]:
            print(f"      - {f}")


def render_markdown(result, top_n=5):
    ov = result["overall"]
    prog = result["progress"]
    L = []
    L.append(f"# {result['bank_title']} · 评估报告")
    L.append("")
    if result.get("respondent"):
        L.append(f"**评估对象：** {result['respondent']}  ")
    L.append(
        f"**综合成熟度：** {_fmt_score(ov['score'])} / {ov['scale_max']} "
        f"—— **{ov['level']}**  "
    )
    L.append(
        f"**完成度：** {prog['answered']}/{prog['total']} "
        f"({prog['completeness'] * 100:.1f}%)  "
    )
    L.append("")
    if ov["score"] is None:
        L.append("> 尚未作答任何题目，无法给出评分。")
        return "\n".join(L)

    L.append("## 一、域得分")
    L.append("")
    L.append("| 域 | 得分 | 等级 | 已答/总数 | 分布 |")
    L.append("|---|---:|---|---|---|")
    for d in result["domains"]:
        L.append(
            f"| {d['label']} | {_fmt_score(d['score'])} | {d['level']} "
            f"| {d['answered']}/{d['total']} | `{_bar(d['score'])}` |"
        )

    L.append("")
    L.append("## 二、能力域得分")
    L.append("")
    L.append("| 域 | 能力域 | 得分 | 等级 | 已答/总数 |")
    L.append("|---|---|---:|---|---|")
    cur = None
    for g in result["groups"]:
        if g["domain"] != cur:
            cur = g["domain"]
            dlabel = next((d["label"] for d in result["domains"] if d["id"] == cur), cur)
            L.append(f"| **{dlabel}** | | | | |")
        L.append(
            f"| | {g['label']} | {_fmt_score(g['score'])} | {g['level']} "
            f"| {g['answered']}/{g['total']} |"
        )

    L.append("")
    L.append(f"## 三、最需改进的 {top_n} 个能力域")
    L.append("")
    L.append("| 排名 | 能力域 | 得分 | 等级 | 改进方向 |")
    L.append("|---:|---|---:|---|---|")
    for i, g in enumerate(result["weakest_groups"], 1):
        nxt = _next_level_hint(g["score"], result.get("scale_levels") or [])
        L.append(f"| {i} | {g['label']} | {_fmt_score(g['score'])} | {g['level']} | {nxt} |")

    if result["low_questions"]:
        L.append("")
        L.append("## 四、低分题目清单（≤2 分）")
        L.append("")
        L.append("| 题目 ID | 能力域 | 答案 | 得分 | 题目 |")
        L.append("|---|---|---|---:|---|")
        for q in result["low_questions"][:30]:
            t = q["text"].replace("\n", " ")
            t = t if len(t) <= 90 else t[:90] + "…"
            L.append(f"| {q['id']} | {q['group_label']} | {q.get('answer')} | {q['score']:.0f} | {t} |")
        if len(result["low_questions"]) > 30:
            L.append(f"| … | | | | 另有 {len(result['low_questions']) - 30} 题 |")

    if result.get("na_answers"):
        L.append("")
        L.append(f"## 五、回答「不适用」的题目（{len(result['na_answers'])} 题）")
        L.append("")
        L.append(
            "N/A 按题库设定计入得分（多数为 1 分，少数为 0 分），因此会影响分数。"
            "但这些题代表「不适用」而非能力不足，建议访谈时复核其合理性——"
            "N/A 过多可能意味着受访方在回避问题。"
        )
        L.append("")
        L.append("| 题目 ID | 能力域 | 计入分值 | 题目 |")
        L.append("|---|---|---:|---|")
        for q in result["na_answers"][:30]:
            t = q["text"].replace("\n", " ")
            t = t if len(t) <= 90 else t[:90] + "…"
            L.append(f"| {q['id']} | {q['group_label']} | {q['score']:.0f} | {t} |")
        if len(result["na_answers"]) > 30:
            L.append(f"| … | | | 另有 {len(result['na_answers']) - 30} 题 |")

    if result["unanswered"]:
        L.append("")
        L.append(f"## 六、未作答题目（{len(result['unanswered'])} 题）")
        L.append("")
        L.append("未作答题目不参与计分，因此当前分数基于已完成部分计算。")
        L.append("")
        L.append("`" + "`, `".join(result["unanswered"][:60]) + "`")
        if len(result["unanswered"]) > 60:
            L.append(f"… 另有 {len(result['unanswered']) - 60} 题")

    if result["warnings"]:
        L.append("")
        L.append("## 七、数据告警")
        L.append("")
        for w in result["warnings"]:
            L.append(f"- {w}")

    return "\n".join(L)


def _current_level_index(score, levels):
    for i, lv in enumerate(levels):
        mx = lv.get("max_exclusive")
        if mx is None or score < mx:
            return i
    return len(levels) - 1


def _next_level_hint(score, levels):
    """给出"再上一级"的目标描述，用于改进建议。"""
    if score is None or not levels:
        return "尚未评估"
    i = _current_level_index(score, levels)
    if i + 1 >= len(levels):
        return "已达最高级，维持并持续改进"
    nxt = levels[i + 1]
    desc = (nxt.get("desc") or "").strip()
    desc = desc if len(desc) <= 60 else desc[:60] + "…"
    return f"→ {nxt.get('label','')}：{desc}"


# ---------------- 子命令 ----------------

def print_data_quality(bank, limit=5):
    """打印题库自带的原始数据缺陷（若有）。"""
    dq = (bank.raw or {}).get("data_quality")
    if not dq or not dq.get("issues"):
        return
    print("")
    print(f"[数据质量] 原始题库自带 {dq['count']} 处缺陷，引擎按原样计分以保持与源系统一致：")
    for i in dq["issues"][:limit]:
        print(f"  - {i['id']} [{i['type']}] {i['detail']}")
    if dq["count"] > limit:
        print(f"  … 另有 {dq['count'] - limit} 处，详见题库 data_quality 字段")
    print("  实际评估时应就这些题目向受访方口头确认，不要直接采信其得分。")


def cmd_banks(args):
    bs = list_banks()
    if not bs:
        print("内置题库目录为空:", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets"))
        return
    print(f"{'bank_id':<20} {'题数':>5} {'组':>4} {'域':>4}  标题")
    for b in bs:
        print(f"{b['bank_id']:<20} {b['questions']:>5} {b['groups']:>4} {b['domains']:>4}  {b['title']}")


def cmd_info(args):
    bank = load_bank(args.bank)
    s = bank.size
    print(f"题库: {bank.title} ({bank.bank_id})")
    print(f"来源: {bank.path}")
    print(f"规模: {s['questions']} 题 / {s['groups']} 组 / {s['domains']} 域")
    if bank.description:
        print(f"说明: {bank.description}")
    print(f"聚合: 组={bank.agg['group']} 域={bank.agg['domain']} 总分={bank.agg['overall']}")
    print("")
    for d in bank.domains:
        gs = bank.groups_of_domain(d["id"])
        qs = bank.questions_of_domain(d["id"])
        print(f"[{d['id']}] {d.get('label')} — {len(gs)} 组 / {len(qs)} 题")
        if args.verbose:
            for g in gs:
                n = len(bank.questions_of_group(g["id"]))
                print(f"    - {g['id']}  {g.get('label')}  ({n} 题)")
    print_data_quality(bank)


def cmd_show(args):
    bank = load_bank(args.bank)
    qs = bank.questions
    if args.group:
        qs = bank.questions_of_group(args.group)
        if not qs:
            raise BankError(f"找不到组 {args.group}")
    elif args.domain:
        if args.domain not in bank._domain_label:
            raise BankError(f"找不到域 {args.domain}，可选: {list(bank._domain_label)}")
        qs = bank.questions_of_domain(args.domain)
    for i, q in enumerate(qs, 1):
        print_question(q, idx=i, compact=args.compact)
    print(f"\n共 {len(qs)} 题")


def cmd_template(args):
    bank = load_bank(args.bank)
    qs = bank.questions
    if args.domain:
        qs = bank.questions_of_domain(args.domain)
    elif args.group:
        qs = bank.questions_of_group(args.group)
    doc = {
        "bank": bank.bank_id,
        "respondent": args.respondent or "",
        "meta": {"created_by": "qscore.py", "note": "答案填选项字母，如 A/B/C/D/E 或 N/A；留空表示未作答"},
        "answers": {q["id"]: "" for q in qs},
    }
    text = json.dumps(doc, ensure_ascii=False, indent=2)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"已生成答案模板: {args.out}  ({len(qs)} 题)")
    else:
        print(text)


def cmd_next(args):
    bank_id, answers, respondent, meta = load_answers(args.answers)
    bank = load_bank(args.bank or bank_id or DEFAULT_BANK)
    todo = [q for q in bank.questions if not str(answers.get(q["id"]) or "").strip()]
    if args.group:
        todo = [q for q in todo if q.get("group") == args.group]
    if args.domain:
        todo = [q for q in todo if q.get("domain") == args.domain]
    print(f"剩余未答: {len(todo)} / {len(bank.questions)}")
    for i, q in enumerate(todo[: args.limit], 1):
        print_question(q, idx=i, compact=args.compact)


def cmd_score(args):
    bank_id, answers, respondent, meta = load_answers(args.answers)
    bank = load_bank(args.bank or bank_id or DEFAULT_BANK)
    result = bank.evaluate(answers, respondent=args.respondent or respondent, top_n=args.top)
    result["bank_file"] = bank.path
    result["data_quality"] = (bank.raw or {}).get("data_quality")

    if args.format == "json":
        text = json.dumps(result, ensure_ascii=False, indent=2)
    elif args.format == "html":
        text = report_html.render(result, top_n=args.top)
    else:
        text = render_markdown(result, top_n=args.top)

    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"报告已写入: {args.out}")
        ov = result["overall"]
        print(f"综合得分: {_fmt_score(ov['score'])} ({ov['level']})  "
              f"完成度 {result['progress']['answered']}/{result['progress']['total']}")
        for d in result["domains"]:
            print(f"  {d['label']}: {_fmt_score(d['score'])} ({d['level']})")
    else:
        print(text)
    if result.get("data_quality", {}).get("issues"):
        print(f"\n[数据质量] 题库自带 {result['data_quality']['count']} 处缺陷，"
              f"相关题目得分仅供参考，建议口头复核。")


def cmd_ask(args):
    """终端交互式作答：逐题打印选项，等待输入。"""
    bank = load_bank(args.bank)
    answers = {}
    if args.answers and os.path.isfile(args.answers):
        _, answers, _, _ = load_answers(args.answers)
        answers = dict(answers)

    qs = bank.questions
    if args.group:
        qs = bank.questions_of_group(args.group)
    elif args.domain:
        qs = bank.questions_of_domain(args.domain)
    qs = [q for q in qs if not str(answers.get(q["id"]) or "").strip()]

    print(f"交互式作答：{bank.title} — 共 {len(qs)} 题待答")
    print("输入选项字母回车确认；直接回车跳过；输入 q 结束并保存。\n")
    for i, q in enumerate(qs, 1):
        print_question(q, idx=i)
        valid = {str(o["label"]).upper() for o in q["options"]}
        if q.get("na"):
            valid.add("N/A")
        while True:
            try:
                raw = input("你的答案> ").strip()
            except EOFError:
                raw = "q"
            if raw.lower() == "q":
                qs = qs[: i - 1]
                break
            if raw == "":
                break
            if raw.upper() in valid:
                answers[q["id"]] = raw.upper()
                break
            print(f"  无效输入，可选: {'/'.join(sorted(valid))}")
        if raw.lower() == "q":
            break

    out = args.out or args.answers or "answers.json"
    doc = {"bank": bank.bank_id, "respondent": args.respondent or "", "answers": answers}
    with open(out, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    print(f"\n已保存 {sum(1 for v in answers.values() if str(v).strip())} 条答案 -> {out}")
    if args.score:
        result = bank.evaluate(answers, respondent=args.respondent)
        print(render_markdown(result, top_n=args.top))


def cmd_fill(args):
    """批量填充答案，用于冒烟测试 / 看量表边界 / 演示。"""
    import random as _rnd

    bank = load_bank(args.bank)
    answers = {}
    respondent = args.respondent or ""
    if args.answers and os.path.isfile(args.answers):
        _, answers, respondent0, _ = load_answers(args.answers)
        answers = dict(answers)
        respondent = respondent or respondent0 or ""

    seed = args.seed if args.seed is not None else int(time.time())
    _rnd.seed(seed)

    stat = {"set": 0, "blank": 0, "na": 0}
    notes = []

    for q in bank.questions:
        qid = q["id"]
        labels = [str(o["label"]).upper() for o in q["options"]]
        graded = [l for l in labels if l != "N/A"]      # 计分选项（不含 N/A）
        pool = labels + ([q["na"]["label"]] if q.get("na") else [])

        if args.strategy.startswith("all:"):
            want = args.strategy.split(":", 1)[1].strip().upper()
            if want in pool:
                answers[qid] = want
            else:
                # 该题没有这个选项（题库里确实存在只有 1 个选项的题）
                fallback = graded[0] if graded else (pool[0] if pool else "")
                answers[qid] = fallback
                notes.append(f"{qid}: 无 {want} 选项，已改用 {fallback}")
        elif args.strategy == "random":
            if _rnd.random() < args.blank_rate:
                answers[qid] = ""
                stat["blank"] += 1
                continue
            c = _rnd.choice(pool)
            answers[qid] = c
            stat["na"] += (c.upper() == "N/A")
        elif args.strategy == "first":      # 最低档：量表下界
            answers[qid] = graded[0] if graded else ""
        elif args.strategy == "last":       # 最高档：量表上界
            answers[qid] = graded[-1] if graded else ""
        else:
            raise BankError(f"未知策略 {args.strategy}")
        if str(answers[qid]).strip():
            stat["set"] += 1

    doc = {
        "bank": bank.bank_id,
        "respondent": respondent,
        "meta": {
            "filled_by": "qscore.py fill",
            "strategy": args.strategy,
            "seed": seed if args.strategy == "random" else None,
        },
        "answers": answers,
    }
    out = args.out or args.answers or "answers.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)

    print(f"已填充 {stat['set']} 条 -> {out}")
    if args.strategy == "random":
        print(f"  策略=random  种子={seed}  留空={stat['blank']}  N/A={stat['na']}")
    else:
        print(f"  策略={args.strategy}")
    for n in notes[:10]:
        print(f"  [注意] {n}")
    if len(notes) > 10:
        print(f"  …另有 {len(notes) - 10} 道题目缺少该选项")

    if args.score:
        result = bank.evaluate(answers, respondent=respondent, top_n=args.top)
        if args.format == "html":
            text = report_html.render(result, top_n=args.top)
        elif args.format == "json":
            text = json.dumps(result, ensure_ascii=False, indent=2)
        else:
            text = render_markdown(result, top_n=args.top)
        if args.report_out:
            os.makedirs(os.path.dirname(os.path.abspath(args.report_out)), exist_ok=True)
            with open(args.report_out, "w", encoding="utf-8") as f:
                f.write(text)
            print(f"  报告已写入: {args.report_out}")
        else:
            print(text)
        ov = result["overall"]
        print(f"  综合得分: {_fmt_score(ov['score'])} ({ov['level']})  "
              f"完成度 {result['progress']['answered']}/{result['progress']['total']}")


def cmd_validate(args):
    path = resolve_bank_path(args.bank_file)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    try:
        bank = Bank(data, path=path)
    except BankError as e:
        print(f"[FAIL] {path}\n  {e}")
        sys.exit(1)
    s = bank.size
    print(f"[OK] {path}")
    print(f"  bank_id={bank.bank_id}  题={s['questions']} 组={s['groups']} 域={s['domains']}")
    # 额外一致性检查
    no_group = [q["id"] for q in bank.questions if not q.get("group")]
    orphan = [g["id"] for g in bank.groups if not bank.questions_of_group(g["id"])]
    if no_group:
        print(f"  [警告] {len(no_group)} 题未归属任何组（不影响计分，但无法出分组报告）")
    if orphan:
        print(f"  [警告] {len(orphan)} 个组没有任何题目: {orphan[:5]}")
    print_data_quality(bank)


# ---------------- CLI ----------------

def main():
    ap = argparse.ArgumentParser(
        prog="qscore.py", description="问卷评分引擎 CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("banks", help="列出可用题库").set_defaults(func=cmd_banks)

    p = sub.add_parser("info", help="题库概览")
    p.add_argument("--bank", default=DEFAULT_BANK)
    p.add_argument("-v", "--verbose", action="store_true")
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("show", help="打印题目")
    p.add_argument("--bank", default=DEFAULT_BANK)
    p.add_argument("--domain")
    p.add_argument("--group")
    p.add_argument("--compact", action="store_true", help="只打印选项与分值，不展开选项全文")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("template", help="生成空白答案文件")
    p.add_argument("--bank", default=DEFAULT_BANK)
    p.add_argument("--domain")
    p.add_argument("--group")
    p.add_argument("--respondent", default="")
    p.add_argument("--out")
    p.set_defaults(func=cmd_template)

    p = sub.add_parser("next", help="列出未作答题目")
    p.add_argument("answers")
    p.add_argument("--bank")
    p.add_argument("--domain")
    p.add_argument("--group")
    p.add_argument("-n", "--limit", type=int, default=5, help="最多显示几道未作答题")
    p.add_argument("--compact", action="store_true")
    p.set_defaults(func=cmd_next)

    p = sub.add_parser("score", help="评分并生成报告")
    p.add_argument("answers")
    p.add_argument("--bank")
    p.add_argument("--format", choices=["md", "html", "json"], default="md",
                   help="md=Markdown；html=带雷达图的单文件网页（适合给人看）；json=结构化")
    p.add_argument("--out")
    p.add_argument("--respondent")
    p.add_argument("--top", type=int, default=5)
    p.set_defaults(func=cmd_score)

    p = sub.add_parser("ask", help="终端交互式作答")
    p.add_argument("--bank", default=DEFAULT_BANK)
    p.add_argument("--domain")
    p.add_argument("--group")
    p.add_argument("--answers")
    p.add_argument("--out")
    p.add_argument("--respondent", default="")
    p.add_argument("--score", action="store_true", help="答完立即出报告")
    p.add_argument("--top", type=int, default=5)
    p.set_defaults(func=cmd_ask)

    p = sub.add_parser("fill", help="批量填充答案（冒烟测试/看量表边界）")
    p.add_argument("answers", nargs="?", help="要填充的答案文件（不存在则新建）")
    p.add_argument("--bank", default=DEFAULT_BANK)
    p.add_argument("--strategy", default="all:B",
                   help="all:B 全选某选项 / random 随机 / first 全选最低档 / last 全选最高档")
    p.add_argument("--seed", type=int, help="random 策略的随机种子（不填则用当前时间）")
    p.add_argument("--blank-rate", type=float, default=0.12, help="random 策略的留空比例")
    p.add_argument("--respondent", default="")
    p.add_argument("--out")
    p.add_argument("--score", action="store_true", help="填完立刻出报告")
    p.add_argument("--format", choices=["md", "html", "json"], default="md")
    p.add_argument("--report-out", help="--score 时报告的输出路径")
    p.add_argument("--top", type=int, default=5)
    p.set_defaults(func=cmd_fill)

    p = sub.add_parser("validate", help="校验题库格式")
    p.add_argument("bank_file")
    p.set_defaults(func=cmd_validate)

    args = ap.parse_args()
    try:
        args.func(args)
    except BankError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
